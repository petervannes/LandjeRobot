# LandjeRobot

This is the Landje Robot library. A library to control a simple affordable STEM object advoidance and line following robot using a simplified and reduced instruction set. 

